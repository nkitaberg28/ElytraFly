<?php

namespace ExtraVanilla\item;

use pocketmine\utils\CloningRegistryTrait;
use pocketmine\item\Item;

/**
 * @method static Elytra ELYTRA()
 */
final class VanillaItems
{
    use CloningRegistryTrait;

    public static function register(string $name, Item $item) : void
    {
        self::_registryRegister($name, $item);
    }

    /**
     * @return Item[]
     */
    public static function getAll() : array
    {
        /** @var Item[] $items */
        $items = self::_registryGetAll();

        return $items;
    }

    public static function setup() : void
    {
        self::register("elytra", new Elytra());
    }
}
