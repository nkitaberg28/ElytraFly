<?php

namespace ExtraVanilla\item;

final class ItemTypeIds
{
    public const ELYTRA = 444;
}
