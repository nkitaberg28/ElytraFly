<?php

namespace ExtraVanilla\item;

use ExtraVanilla as Plugin;
use pocketmine\scheduler\AsyncTask;
use pocketmine\data\bedrock\item\ItemTypeNames;
use pocketmine\item\Item;
use pocketmine\world\format\io\GlobalItemDataHandlers;
use pocketmine\data\bedrock\item\SavedItemData;
use pocketmine\item\StringToItemParser;

class ItemManager
{
    public static function init() : void
    {
        self::register();

        $server = Plugin::getInstance()->getServer();

        $server->getAsyncPool()->addWorkerStartHook(
            function (int $worker) use ($server) : void
            {
                $server->getAsyncPool()->submitTaskToWorker(
                    new class extends AsyncTask
                    {
                        public function onRun() : void
                        {
                            ItemManager::register();
                        }
                    }, $worker
                );
            }
        );
    }

    public static function register() : void
    {
        self::registerSimple(ItemTypeNames::ELYTRA, new Elytra(), ["elytra"]);
    }

    public static function registerSimple(string $id, Item $item, array $stringToItemParserNames) : void
    {
        GlobalItemDataHandlers::getDeserializer()->map($id, fn () => clone $item);
        GlobalItemDataHandlers::getSerializer()->map($item, fn () => new SavedItemData($id));

        foreach ($stringToItemParserNames as $name)
        {
            StringToItemParser::getInstance()->override($name, fn () => clone $item);
        }
    }
}
