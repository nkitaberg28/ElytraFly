<?php

namespace ExtraVanilla\item;

use pocketmine\item\Armor;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ArmorTypeInfo;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\ItemTypeIds;

class Elytra extends Armor
{
    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemTypeIds::ELYTRA), "Elytra", new ArmorTypeInfo(0, 432, ArmorInventory::SLOT_CHEST));
    }
}
