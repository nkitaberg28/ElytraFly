<?php

namespace ExtraVanilla\entity\animation;

use pocketmine\entity\animation\Animation;
use ExtraVanilla\entity\FireworksRocket;
use pocketmine\network\mcpe\protocol\ActorEventPacket;
use pocketmine\network\mcpe\protocol\types\ActorEvent;

class FireworkParticleAnimation implements Animation
{
    private FireworksRocket $fireworksRocket;

    public function __construct(FireworksRocket $fireworksRocket)
    {
        $this->fireworksRocket = $fireworksRocket;
    }

    public function encode() : array
    {
        return [

            ActorEventPacket::create($this->fireworksRocket->getId(), ActorEvent::FIREWORK_PARTICLES, 0)
        ];
    }
}
