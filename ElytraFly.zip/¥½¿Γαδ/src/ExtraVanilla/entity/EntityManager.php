<?php

namespace ExtraVanilla\entity;

use pocketmine\entity\EntityFactory;
use pocketmine\world\World;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\entity\EntityDataHelper;
use pocketmine\item\FireworkRocket;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;

final class EntityManager
{
    public static function init() : void
    {
        EntityFactory::getInstance()->register(

            FireworksRocket::class,
            function(World $world, CompoundTag $nbt) : FireworksRocket
            {
                return new FireworksRocket(EntityDataHelper::parseLocation($nbt, $world), new FireworkRocket(new ItemIdentifier(ItemTypeIds::FIREWORK_ROCKET), "Firework Rocket"));
            },
            ["FireworksRocket", "FireworkRocket", "minecraft:firework_rocket", "minecraft:fireworks_rocket"]
        );
    }
}
