<?php

namespace ExtraVanilla\entity;

use pocketmine\entity\Entity;
use pocketmine\entity\Location;
use pocketmine\item\FireworkRocket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\network\mcpe\protocol\types\LevelSoundEvent;
use ExtraVanilla\entity\animation\FireworkParticleAnimation;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataCollection;
use pocketmine\network\mcpe\protocol\types\CacheableNbt;
use pocketmine\item\FireworkRocketType;

class FireworksRocket extends Entity
{
    protected int $lifeTime = 0;
    protected FireworkRocket $fireworkRocket;

    public const DATA_FIREWORK_ITEM = 16;

    public function __construct(Location $location, FireworkRocket $fireworkRocket, ?int $lifeTime = null)
    {
        $nbt = $fireworkRocket->getNamedTag();

        parent::__construct($location, $nbt);

        $this->fireworkRocket = $fireworkRocket;
        $this->setMotion(new Vector3(0.001, 0.05, 0.001));

        if ($nbt->getCompoundTag("FireworksRocket"))
        {
            $this->setLifeTime($lifeTime ?? (($fireworkRocket->getFlightDurationMultiplier() + 1) * 10) + mt_rand(0, 12));
        }

        $packet = LevelSoundEventPacket::create(LevelSoundEvent::LAUNCH, $this->location->asVector3(), -1, ":", false, false);

        $location->getWorld()->broadcastPacketToViewers($this->location, $packet);
    }

    public function getLifeTime() : int
    {
        return $this->lifeTime;
    }

    public function setLifeTime(int $lifeTime) : void
    {
        $this->lifeTime = $lifeTime;
    }

    public function doLifeTimeTick() : bool
    {
        if (--$this->lifeTime < 0 && !$this->isFlaggedForDespawn())
        {
            $this->doExplosionAnimation();
            $this->playSounds();
            $this->flagForDespawn();
            return true;
        }

        return false;
    }

    public function doExplosionAnimation() : void
    {
        $this->broadcastAnimation(new FireworkParticleAnimation($this), $this->getViewers());
    }

    public function playSounds(): void
    {
        $fireworkRocketTag = $this->fireworkRocket->getNamedTag()->getCompoundTag("FireworksRocket");

        if ($fireworkRocketTag)
        {
            $explosionsTag = $fireworkRocketTag->getListTag("Explosions");

            if ($explosionsTag)
            {
                foreach ($explosionsTag->getValue() as $tag)
                {
                    if ($tag instanceof CompoundTag)
                    {
                        $world = $this->getWorld();
                        $location = $this->location;
                        $position = $location->asVector3();

                        if ($tag->getByte("FireworkType", 0) == FireworkRocketType::LARGE_BALL)
                        {
                            $world->broadcastPacketToViewers($location, LevelSoundEventPacket::create(LevelSoundEvent::LARGE_BLAST, $position, -1, ":", false, false));
                        } else
                        {
                            $world->broadcastPacketToViewers($location, LevelSoundEventPacket::create(LevelSoundEvent::BLAST, $position, -1, ":", false, false));
                        }

                        if ($tag->getByte("FireworkFlicker", 0) == 1)
                        {
                            $world->broadcastPacketToViewers($location, LevelSoundEventPacket::create(LevelSoundEvent::TWINKLE, $position, -1,":", false, false));
                        }
                    }
                }
            }
        }
    }

    public static function getNetworkTypeId() : string
    {
        return EntityIds::FIREWORKS_ROCKET;
    }

    public function getInitialSizeInfo() : EntitySizeInfo
    {
        return new EntitySizeInfo(0.25, 0.25);
    }

    public function getInitialDragMultiplier() : float
    {
        return 1.0;
    }

    public function getInitialGravity() : float
    {
        return 1.0;
    }

    public function entityBaseTick(int $tickDiff = 1) : bool
    {
        if ($this->closed)
        {
            return false;
        }

        $hasUpdate = parent::entityBaseTick($tickDiff);

        if ($this->doLifeTimeTick())
        {
            $hasUpdate = true;
        }

        return $hasUpdate;
    }

    public function syncNetworkData(EntityMetadataCollection $properties) : void
    {
        parent::syncNetworkData($properties);
        $properties->setCompoundTag(self::DATA_FIREWORK_ITEM, new CacheableNbt($this->fireworkRocket->getNamedTag()));
    }

    protected function tryChangeMovement() : void
    {
        $this->motion->x *= 1.15;
        $this->motion->y += 0.04;
        $this->motion->z *= 1.15;
    }
}
