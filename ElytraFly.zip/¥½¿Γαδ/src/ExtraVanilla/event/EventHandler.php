<?php

namespace ExtraVanilla\event;

use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\player\Player;
use pocketmine\item\ItemTypeIds;

class EventHandler implements Listener
{
    public function EntityDamageEvent(EntityDamageEvent $event) : void
    {
        $entity = $event->getEntity();

        if ($entity instanceof Player && $entity->isGliding() && $entity->getArmorInventory()->getChestplate()->getTypeId() == ItemTypeIds::ELYTRA && $event->getCause() == EntityDamageEvent::CAUSE_FALL)
        {
            $event->cancel();
        }
    }
}
