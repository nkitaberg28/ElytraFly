<?php

use pocketmine\plugin\PluginBase;
use ExtraVanilla\item\ItemManager;
use ExtraVanilla\entity\EntityManager;
use ExtraVanilla\event\EventHandler;

class ExtraVanilla extends PluginBase
{
    private static self $instance;

    public function onEnable() : void
    {
        self::$instance = $this;

        ItemManager::init();
        EntityManager::init();

        $this->getServer()->getPluginManager()->registerEvents(new EventHandler(), $this);
    }

    public static function getInstance() : self
    {
        return self::$instance;
    }
}
